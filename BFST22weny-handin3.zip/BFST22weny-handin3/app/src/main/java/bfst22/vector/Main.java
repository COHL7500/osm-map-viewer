package bfst22.vector;

import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(App.class, args);
    }
}
